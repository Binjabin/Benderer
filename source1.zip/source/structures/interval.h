//
// Created by binjabin on 6/24/25.
//

#ifndef INTERVAL_H
#define INTERVAL_H
#include "../benderer.h"

class interval {
public:
    double min, max;

    interval() : min( +infinity ), max( -infinity ) {
    };

    interval( double min, double max ) : min( min ), max( max ) {
    }

    interval( const interval& a, const interval& b) {
        min = (a.min <= b.min) ? a.min : b.min;
        max = (a.max >= b.max) ? a.max : b.max;
    }

    double size() const {
        return max - min;
    }

    bool contains( double x ) const {
        return min <= x && x <= max;
    }

    bool surrounds( double x ) const {
        return min < x && x < max;
    }

    double clamp(double x) const {
        if (x < min) return min;
        if (x > max) return max;
        return x;
    }

    interval expand (double delta) const {
        auto padding = delta / 2.0;
        return interval(min - padding, max + padding);
    }

    interval crop(double min, double max) {
        interval cropped(clamp(min),clamp(max));
        return cropped;
    }

    static const interval empty, universe;
};

const interval interval::empty = interval( +infinity, -infinity );
const interval interval::universe = interval( -infinity, +infinity );

interval operator+(const interval& ival, double displacement) {
    return interval(ival.min + displacement, ival.max + displacement);
}

interval operator+(double displacement, const interval& ival) {
    return ival + displacement;
}

#endif //INTERVAL_H
