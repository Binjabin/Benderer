//
// Created by binjabin on 9/27/25.
//

#ifndef MAT_LAMBERTIAN_H
#define MAT_LAMBERTIAN_H

#include "../../texture/texture.h"
#include "../../texture/textures/tex_solid_colour.h"

class lambertian : public material {
public:
    lambertian( const color& albedo ) : tex( make_shared<solid_color>( albedo ) ) {
    }

    lambertian( const shared_ptr<texture> tex ) : tex( tex ) {
    }

    bool scatter( const ray& r_in, const surface_hit& rec, scatter_record& srec ) const override {
        srec.attenuation = tex->value( rec.m_intersection );
        srec.pdf_ptr = make_shared<cosine_pdf>( rec.get_normal() );
        srec.skip_pdf = false;
        return true;
    }

    double scattering_pdf( const ray& r_in, const surface_hit& rec, const ray& scattered ) const override {
        auto cos_theta = dot( rec.get_normal(), unit_vector( scattered.direction() ) );
        return cos_theta < 0 ? 0 : cos_theta / pi;
    }

    color get_attenuation(const surface_hit &rec) const override {
        return tex->value( rec.m_intersection );
    }

    color bsdf(vec3 d_in, const surface_hit &rec, const vec3 &r_out) override {
        //We don't use sampling for this
        return get_attenuation(rec) * (1 / pi);
    }

private:
    shared_ptr<texture> tex;
};

#endif //MAT_LAMBERTIAN_H
