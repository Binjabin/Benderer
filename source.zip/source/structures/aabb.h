//
// Created by binjabin on 7/8/25.
//

#ifndef AABB_H
#define AABB_H
#include "vec3.h"


class aabb {
public:
    interval x, y, z;

    aabb() {
    }

    aabb( const interval& x, const interval& y, const interval& z )
        : x( x ), y( y ), z( z ) {
        pad_to_minimums();
    }

    aabb( const point3& a, const point3& b ) {
        x = ( a[0] <= b[0] ) ? interval( a[0], b[0] ) : interval( b[0], a[0] );
        y = ( a[1] <= b[1] ) ? interval( a[1], b[1] ) : interval( b[1], a[1] );
        z = ( a[2] <= b[2] ) ? interval( a[2], b[2] ) : interval( b[2], a[2] );

        pad_to_minimums();
    }

    aabb( const aabb& box0, const aabb& box1 ) {
        x = interval( box0.x, box1.x );
        y = interval( box0.y, box1.y );
        z = interval( box0.z, box1.z );

        pad_to_minimums();
    }

    const interval& axis_interval( int n ) const {
        if ( n == 1 ) return y;
        if ( n == 2 ) return z;
        return x;
    }

    bool hit( const ray& r, interval ray_t ) const {
        const point3& ray_orig = r.origin();
        const vec3& ray_dir = r.direction();

        for ( int axis = 0; axis < 3; axis++ ) {
            const interval& ax = axis_interval( axis );
            const double adinv = 1.0 / ray_dir[axis];

            auto t0 = ( ax.min - ray_orig[axis] ) * adinv; //distance of ray until min of bound on axis is reached
            auto t1 = ( ax.max - ray_orig[axis] ) * adinv; //distance of ray until max of bound on axis is reached

            //clip ray to the inside of the box
            if ( t0 < t1 ) {
                if ( t0 > ray_t.min ) ray_t.min = t0;
                if ( t1 < ray_t.max ) ray_t.max = t1;
            }
            else {
                if ( t1 > ray_t.min ) ray_t.min = t1;
                if ( t0 < ray_t.max ) ray_t.max = t0;
            }

            //if the clipped ray has flipped or is length 0, we didn't actually intersect box in this dim.
            if ( ray_t.max <= ray_t.min ) {
                return false;
            }
        }
        //if we are ok in all dimensions, we are in the box
        return true;
    }

    int longest_axis() const {
        if ( x.size() > y.size() ) {
            return ( x.size() > z.size() ) ? 0 : 2;
        }
        else {
            return ( y.size() > z.size() ) ? 1 : 2;
        }
    }

    static const aabb empty, universe;

    //converts world space point into local box coordinates
    vec3 offset(const point3& p) const {
        return vec3(
            (p.x() - x.min) / ( x.size() ),
            (p.y() - y.min) / ( y.size() ),
            (p.z() - z.min) / ( z.size() ));
    }

private:
    void pad_to_minimums() {
        if ( x.size() < epsilon ) x = x.expand( epsilon );
        if ( y.size() < epsilon ) y = y.expand( epsilon );
        if ( z.size() < epsilon ) z = z.expand( epsilon );
    }
};

const aabb aabb::empty = aabb( interval::empty, interval::empty, interval::empty );
const aabb aabb::universe = aabb( interval::universe, interval::universe, interval::universe );

aabb operator+(const aabb& bbox, const vec3& offset) {
    return aabb(bbox.x + offset.x(), bbox.y + offset.y(), bbox.z + offset.z());
}

aabb operator+(const vec3& offset, const aabb& bbox) {
    return bbox + offset;
}
#endif //AABB_H
