//
// Created by binjabin on 9/27/25.
//

#ifndef MAT_METAL_H
#define MAT_METAL_H

class metal : public surface_material {
public:
    metal( const color& albedo, double fuzz ) : albedo( albedo ), fuzz( fuzz < 1 ? fuzz : 1 ) {
    }

    bool scatter( const ray& r_in, const surface_hit_rec& rec, surface_scatter_rec& srec ) const override {
        vec3 reflected = reflect( r_in.direction(), rec.get_normal() );
        reflected = unit_vector( reflected ) + ( fuzz * random_unit_vector() );

        srec.attenuation = get_attenuation(rec);
        srec.s_ray = ray( rec.get_p() + reflected * epsilon, reflected, r_in.time() );
        srec.is_spec = true;

        return true;
    }

    color get_attenuation(const surface_hit_rec &rec) const override {
        return albedo;
    }

    color bsdf(vec3 d_in, const surface_hit_rec &rec, const vec3 &r_out) override {
        //We don't use sampling for this
        return color(0, 0, 0);
    }

private:
    color albedo;
    double fuzz;
};

#endif //MAT_METAL_H
