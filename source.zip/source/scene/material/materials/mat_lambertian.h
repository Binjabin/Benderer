//
// Created by binjabin on 9/27/25.
//

#ifndef MAT_LAMBERTIAN_H
#define MAT_LAMBERTIAN_H

#include "../../texture/texture.h"
#include "../../texture/textures/tex_solid_colour.h"

class lambertian : public surface_material {
public:
    lambertian( const color& albedo ) : tex( make_shared<solid_color>( albedo ) ) {
    }

    lambertian( const shared_ptr<texture> tex ) : tex( tex ) {
    }

    bool scatter( const ray& r_in, const surface_hit_rec& rec, surface_scatter_rec& srec ) const override {
        srec.attenuation = tex->value( rec.m_intersection );

        cosine_pdf scatter_pdf = cosine_pdf( rec.get_normal() );
        vec3 scattered_dir = scatter_pdf.generate();
        srec.s_ray = ray(rec.get_p() + scattered_dir * epsilon, scattered_dir);

        srec.pdf =  scatter_pdf.value(scattered_dir);

        return true;
    }

    color get_attenuation(const surface_hit_rec &rec) const override {
        return tex->value( rec.m_intersection );
    }

    color bsdf(vec3 d_in, const surface_hit_rec &rec, const vec3 &r_out) override {
        //We don't use sampling for this
        return get_attenuation(rec) * (1 / pi);
    }

private:
    shared_ptr<texture> tex;
};

#endif //MAT_LAMBERTIAN_H
