//
// Created by binjabin on 1/25/26.
//

#ifndef BENDERER_MEDIUM_SCATTER_RECORD_H
#define BENDERER_MEDIUM_SCATTER_RECORD_H


#include "../structures/pdf.h"

class medium_scatter_rec {
public:
    ray s_ray;
    color attenuation;
    double pdf = 0.0;
};

#endif //BENDERER_MEDIUM_SCATTER_RECORD_H