//
// Created by binjabin on 1/30/26.
//

#ifndef BENDERER_MEDIUM_SAMPLER_H
#define BENDERER_MEDIUM_SAMPLER_H
#include <memory>

#include "../records/medium_hit_rec.h"
#include "../records/medium_intersection.h"


class medium_sampler {
public:


    static bool sample_distance(const ray& r, medium_intersections& intersections, interval t, medium_hit_rec& rec) {

        auto slices = intersections.get_cropped_slices(t);
        color transmission = colors::white;

        for (const medium_slice& slice : slices) {
            interval w_t = slice.m_interval;
            double t0 = w_t.min;
            double t1 = w_t.max;
            point3 p = r.at(t0);

            const std::vector<shared_ptr<medium_material>>& mats = slice.m_mats;

            // Precompute per-slice homogeneous σ_t sum and a scalar majorant for stepping
            color sigma_t_const = colors::black;
            color sigma_maj = colors::black;
            for (const shared_ptr<medium_material>& mat : mats) {
                sigma_t_const += mat->sigma_t(p);
                sigma_maj += mat->sigma_maj();
            }
            double sigma_maj_scalar = max_component(sigma_maj);

            if (sigma_maj_scalar <= 0) {
                // No extinction in this slice; nothing happens, just continue
                continue;
            }

            //Loop inside slice!
            double cursor_t = t0;
            while (true) {
                double u = random_double();
                double d_t = (-std::log(1 - u)) / sigma_maj_scalar;

                if (cursor_t + d_t > t1) {
                    // Interaction not in this slice, advance to slice end using exact Beer with σ_t_const
                    double dist = t1 - cursor_t;
                    color local_transmission = exp(-sigma_t_const * dist);
                    transmission = transmission * local_transmission;
                    break;
                }

                // Interaction candidate inside slice: move forward
                cursor_t += d_t;
                p = r.at(cursor_t);

                //Apply beer
                color local_transmission = exp(-sigma_t_const * d_t);
                transmission = transmission * local_transmission;

                // For homogeneous slice, σ_t and σ_s are constant; reuse sigma_t_const
                color sigma_t = sigma_t_const;
                color sigma_s = colors::black;
                for (const shared_ptr<medium_material>& mat : mats) {
                    sigma_s += mat->sigma_s(p);
                }
                double sigma_t_scalar = max_component(sigma_t);

                // Acceptance test for real collision
                u = random_double();
                if (u < sigma_t_scalar / sigma_maj_scalar) {
                    // REAL (ie not null).

                    //Choose which medium caused the hit (by σ_s weights)
                    std::vector<double> weights;
                    double sum = 0.0;
                    weights.reserve(mats.size());
                    for (const auto& mat : mats) {
                        color sigma_s_i = mat->sigma_s(p);
                        double w = max_component(sigma_s_i);   // scalar proxy
                        weights.push_back(w);
                        sum += w;
                    }

                    // Fallback: if all weights are zero, pick first to avoid OOB
                    int chosen = 0;
                    if (sum > 0) {
                        double u2 = random_double() * sum;
                        while (u2 > weights[chosen]) {
                            u2 -= weights[chosen];
                            ++chosen;
                        }
                    }

                    shared_ptr<medium_material> chosen_mat = slice.m_mats[chosen];

                    rec.set_t(cursor_t);
                    rec.set_p(p);
                    rec.m_transmittance = transmission;
                    rec.m_mat = chosen_mat;

                    return true;
                }
                else {
                }
            }
        }

        rec.m_transmittance = transmission;
        return false;
    }




    //Calculate (Homogeneous) Transmittance along the ray
    static color transmittance_homogeneous(const ray& r, medium_intersections& intersections, interval t) {
        auto slices = intersections.get_cropped_slices(t);
        color transmission = colors::white;

        for (const medium_slice& slice : slices) {
            interval w_t = slice.m_interval;
            double dt = w_t.size();
            //Since we are homogeneous, this is fine
            point3 p = r.at(w_t.min);

            color sigma_t_sum = colors::black;
            for (auto& mat : slice.m_mats) {
                sigma_t_sum += mat->sigma_t(p);
            }

            //Calculate the beer-lambert based on this per-slice
            color local_transmission = exp(-sigma_t_sum * dt);
            transmission = transmission * local_transmission;
        }
        
        return transmission;
    }
};

#endif //BENDERER_MEDIUM_SAMPLER_H