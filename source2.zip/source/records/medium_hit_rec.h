//
// Created by binjabin on 1/30/26.
//

#ifndef BENDERER_MEDIUM_HIT_REC_H
#define BENDERER_MEDIUM_HIT_REC_H
#include "interaction.h"
class medium_material;

class medium_hit_rec {
public:
    medium_hit_rec()
        : m_interaction(interaction()){
    }

    ~medium_hit_rec() = default;

    double m_t() const { return m_interaction.m_t; }

    void set_t(double t) { m_interaction.m_t = t; }

    point3 m_p() const { return m_interaction.m_p; }

    void set_p(point3 p) { m_interaction.m_p = p; }

    double m_time() const { return m_interaction.m_time; }

    interaction m_interaction;

    //How much color gets through the medium (if it hit, up to the hit point)
    color m_transmittance;

    //phase function
    //std::shared_ptr<material> m_mat;

    //???????
    //double pdf_v = 0.0;



    shared_ptr<medium_material> m_mat;
};

#endif //BENDERER_MEDIUM_HIT_REC_H