//
// Created by binjabin on 6/20/25.
//

#ifndef VEC3_H
#define VEC3_H
#include "../utility/Color/color.h"

class vec3 {
public:
    double e[3];

    //Constructors
    vec3() : e{0, 0, 0} {
    }

    vec3( double e0, double e1, double e2 ): e{e0, e1, e2} {
    }

    //Accessors. Vectors can only be read, not modified component-wise through these.
    double x() const { return e[0]; }
    double y() const { return e[1]; }
    double z() const { return e[2]; }

    vec3 operator-() const {
        return vec3( -e[0], -e[1], -e[2] );
    }

    //Also read-only. Usable with both const and non-const vectors.
    double operator[]( int i ) const {
        return e[i];
    }

    //Can be written through. Only usable with non-const vectors.
    double& operator[]( int i ) {
        return e[i];
    }

    //this is a pointer, and we run operations on and return the object itself.
    //so we need to return the value at this, which is just a pointer

    vec3& operator+=( const vec3& v ) {
        e[0] += v.e[0];
        e[1] += v.e[1];
        e[2] += v.e[2];
        return *this;
    }

    vec3& operator*=( double t ) {
        e[0] *= t;
        e[1] *= t;
        e[2] *= t;
        return *this;
    }

    vec3& operator/=( double t ) {
        return ( *this *= ( 1 / t ) );
    }

    double length_squared() const {
        return e[0] * e[0] + e[1] * e[1] + e[2] * e[2];
    }

    double length() const {
        return std::sqrt( length_squared() );
    }

    bool near_zero() const {
        auto s = 1e-8;
        bool v = ( std::fabs( e[0] ) < s )
            && ( std::fabs( e[1] ) < s )
            && ( std::fabs( e[2] ) < s );

        return v;
    }

    static vec3 random() {
        return vec3( random_double(), random_double(), random_double() );
    }

    static vec3 random( double min, double max ) {
        return vec3(
            random_double( min, max ),
            random_double( min, max ),
            random_double( min, max )
        );
    }
};

//alias (for locations)
using point3 = vec3;

//Inline functions like these are equivalent to substituting code into the call location (at compile time) avoiding jumps

//print vectors
inline std::ostream& operator<<( std::ostream& out, const vec3& v ) {
    return out << v.e[0] << ' ' << v.e[1] << ' ' << v.e[2];
}

inline vec3 operator+( const vec3& u, const vec3& v ) {
    return vec3(
        u.e[0] + v.e[0],
        u.e[1] + v.e[1],
        u.e[2] + v.e[2]
    );
}

inline vec3 operator-( const vec3& u, const vec3& v ) {
    return vec3(
        u.e[0] - v.e[0],
        u.e[1] - v.e[1],
        u.e[2] - v.e[2]
    );
}

inline vec3 operator*( const vec3& u, const vec3& v ) {
    return vec3(
        u.e[0] * v.e[0],
        u.e[1] * v.e[1],
        u.e[2] * v.e[2]
    );
}

inline vec3 operator*( double t, const vec3& v ) {
    return vec3(
        t * v.e[0],
        t * v.e[1],
        t * v.e[2]
    );
}

inline vec3 operator*( const vec3& v, double t ) {
    return t * v;
}

inline vec3 operator/( const vec3& v, double t ) {
    return ( 1 / t ) * v;
}

inline double dot( const vec3& u, const vec3& v ) {
    return (
        u.e[0] * v.e[0] +
        u.e[1] * v.e[1] +
        u.e[2] * v.e[2]
    );
}

inline vec3 cross( const vec3& u, const vec3& v ) {
    return vec3(
        u.e[1] * v.e[2] - u.e[2] * v.e[1],
        u.e[2] * v.e[0] - u.e[0] * v.e[2],
        u.e[0] * v.e[1] - u.e[1] * v.e[0]
    );
}

inline vec3 unit_vector( const vec3& v ) {
    return v / v.length();
}

inline vec3 random_in_unit_disk() {
    while ( true ) {
        auto p = vec3( random_double( -1, 1 ), random_double( -1, 1 ), 0 );
        if ( p.length_squared() < 1 ) {
            return p;
        }
    }
}

inline double max_component( const vec3& v ) {
    return std::max( v.e[0], std::max(v.e[1], v.e[2]));
}

inline vec3 exp( const vec3& v ) {
    double x = exp(v.x());
    double y = exp(v.y());
    double z = exp(v.z());
    return vec3(x, y, z);
}

/*
inline vec3 random_unit_vector() {
    while ( true ) {
        auto p = vec3::random( -1, 1 );
        auto len_sq = p.length_squared();
        if ( 1e-160 < len_sq && len_sq <= 1 ) {
            return p / sqrt( len_sq );
        }
    }
}


inline vec3 random_on_hemisphere( const vec3& normal ) {
    vec3 on_unit_sphere = random_unit_vector();
    if ( dot( on_unit_sphere, normal ) > 0.0 ) {
        return on_unit_sphere;
    }
    else {
        return -on_unit_sphere;
    }
}
*/

inline vec3 reflect( const vec3& v, const vec3& n ) {
    return v - 2 * dot( v, n ) * n;
}

inline vec3 refract( const vec3& uv, const vec3& n, double etai_over_eta_t ) {
    auto cos_theta = std::fmin( dot( -uv, n ), 1.0 );
    vec3 r_out_perp = etai_over_eta_t * ( uv + cos_theta * n );
    vec3 r_out_parallel = -std::sqrt( std::fabs( 1.0 - r_out_perp.length_squared() ) ) * n;
    return ( r_out_perp + r_out_parallel );
}

inline vec3 random_unit_vector() {
    auto r1 = random_double();
    auto r2 = random_double();

    auto phi = 2 * pi * r1;
    auto root = std::sqrt( r2 * (1 - r2) );
    auto x = std::cos( phi ) * 2 * root;
    auto y = std::sin(phi) * root;
    auto z = 1 - 2 * r1;

    return vec3(x, y, z);
}


inline vec3 random_on_hemisphere( const vec3& normal ) {
    vec3 on_unit_sphere = random_unit_vector();
    if ( dot( on_unit_sphere, normal ) > 0.0 ) {
        return on_unit_sphere;
    }
    else {
        return -on_unit_sphere;
    }
}

inline vec3 random_cosine_direction() {
    auto r1 = random_double();
    auto r2 = random_double();

    auto phi = 2 * pi * r1;
    auto x = std::cos( phi ) * std::sqrt( r2 );
    auto y = std::sin(phi) * std::sqrt( r2 );
    auto z = sqrt(1 - r2);

    return vec3(x, y, z);
}


const vec3 uninit_vec = vec3(uninit, uninit, uninit);


#endif //VEC3_H
