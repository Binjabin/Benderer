//
// Created by binjabin on 1/25/26.
//

#ifndef BENDERER_SIMPLE_MEDIUM_PATH_TRACER_H
#define BENDERER_SIMPLE_MEDIUM_PATH_TRACER_H

#include "../records/medium_scatter_rec.h"
#include "../scene/scene.h"
#include "../scene/material/surface_material.h"
#include "../records/path_result.h"
#include "../records/path_state.h"
#include "../samplers/medium_sampler.h"

class simple_medium_path_tracer : public integrator {

public:
    simple_medium_path_tracer(int max_depth)
        : m_max_depth(max_depth) {
    };

    // Correctly override integrator::ray_color (const-correct signature)
    color ray_color(const ray &r, int depth, const world& world) const override {
        path_state p_state = initial_path_state();
        path_result res = path_trace(r, world, p_state);
        return res.radiance_from_path;
    }


private:
    int m_max_depth;

    path_result path_trace(const ray& r, const world& world, path_state& p_state) const {

        path_result out_result = path_result();

        //---------------------------------------
        // Terminate if our throughput becomes 0 (or close)
        if (max_component(p_state.overall_throughput) < epsilon) {
            return empty_path_result();
        }

        //---------------------------------------
        // Check for a surface hit
        surface_hit_rec rec;
        interval ray_t = interval(epsilon, infinity);
        bool hit_surface = world.m_surfaces->surface_hit( r, ray_t, rec );

        //---------------------------------------
        // Check for a medium hits

        double end_t = hit_surface ? rec.get_t() : infinity;
        interval medium_interval = interval(epsilon, end_t);

        medium_intersections medium_recs;
        bool intersect_medium = world.m_mediums->medium_hit(r, ray_t, medium_recs);
        medium_hit_rec medium_rec;

        bool hit_medium = false;
        if (intersect_medium) {
            hit_medium = medium_sampler::sample_distance(r, medium_recs, medium_interval, medium_rec);
        }

        //If we have gone through a medium and not scattered, we work out transmittance here
        color media_transmittance = colors::white;
        if (intersect_medium) {
            if (hit_medium) {
                media_transmittance = medium_rec.m_transmittance;
            }
            else {
                //Use beer:
                media_transmittance = medium_sampler::transmittance_homogeneous(r, medium_recs, medium_interval);
            }
        }

        //---------------------------------------
        // If no intersection, default to skybox
        if (!(hit_surface || hit_medium)) {
            color col_from_sky = world.m_sky->sample_color(r.direction());
            color res = col_from_sky * media_transmittance;
            return color_path_result(res);
        }

        //Either we hit medium and not surface, or hit medium and surface, but surface after
        bool hit_medium_first = hit_medium && ((!hit_surface) || medium_rec.m_t() < rec.get_t());

        if (hit_medium_first){
            //If we do hit the medium first, use this for scattering/absorption
            auto p = medium_rec.m_p();
            auto d = -r.direction();
            color emittance = medium_rec.m_mat->emission(p);

            //---------------------------------------
            // Get the properties of the medium at the interaction point

            color sigma_s = medium_rec.m_mat->sigma_s(p);
            double sigma_s_scalar = max_component(sigma_s);

            //---------------------------------------
            // Otherwise we scatter!
            // We have a max depth. Terminate if the next sample would exceed that depth.
            if (p_state.depth + 1 >= m_max_depth) {
                return color_path_result(emittance * media_transmittance);
            }

            //the transmittance to the scatter point
            color transmittance = medium_rec.m_transmittance;
            double transmittance_scalar = max_component(transmittance);

            double channel_pdf = transmittance_scalar * sigma_s_scalar;

            medium_scatter_rec srec;
            medium_rec.m_mat->scatter(-r.direction(), srec);
            ray sray = ray(p, srec.s_dir);

            color throughput = transmittance * (sigma_s / channel_pdf)  * (srec.phase_pdf / srec.w_pdf);


            //Otherwise we have scattered,
            path_state child_state = p_state;
            child_state.depth++; // advance path depth for medium bounce
            child_state.overall_throughput = p_state.overall_throughput * throughput;
            path_result indirect_res = path_trace(sray, world, child_state);

            // Accumulate emission at the medium point (if any)
            out_result.radiance_from_path += (emittance + indirect_res.radiance_from_path * throughput) * transmittance;
            return out_result;
        }

        //---------------------------------------
        // Get surface emittance
        color surface_emittance = rec.m_mat->emitted(r, rec, rec.get_u(), rec.get_v(), rec.get_p());

        //---------------------------------------
        // We have a max depth. Terminate if the next sample exceeds that depth.
        if (p_state.depth + 1 >= m_max_depth) {
            color res = surface_emittance * media_transmittance;
            return color_path_result(res);
        }

        //---------------------------------------
        // Otherwise, calculate ray "scatter". Either absorb ray (just return emittance, no more bounces) or calculate the scatter direction

        surface_scatter_rec srec;
        bool scattered = rec.m_mat->scatter(r, rec, srec);

        //If we don't scatter, then we exit early
        if (!scattered) {
            color res = surface_emittance * media_transmittance;
            path_result no_scatter = color_path_result(res);
            return no_scatter;
        }

        //----------------------------------------
        // If our ray is scattered, we take another step, an indirect sample
        // Generate a scatter direction, and calculate lighting from that direction down our ray

        path_result indirect_res = get_indirect_result(r, world, p_state, srec, rec);

        out_result = indirect_res;
        color from_surface = out_result.radiance_from_path + surface_emittance;
        from_surface = from_surface * media_transmittance;
        out_result.radiance_from_path = from_surface;
        return out_result;
    }

    path_result get_indirect_result(const ray& r, const world& world, const path_state& p_state, const surface_scatter_rec& srec, const surface_hit_rec& rec) const {
        path_result indirect_res = empty_path_result();
        path_state child_state = p_state;
        child_state.depth++;
        if (srec.is_spec) {

            //prev bsdf is meaningless for specular. Just keep sensible.
            child_state.prev_bsdf_pdf = 1.0;

            //attenuation is like the throughput of spec surfaces
            child_state.overall_throughput = srec.bsdf * child_state.overall_throughput;
            indirect_res = path_trace(srec.s_ray, world, child_state);
            indirect_res.radiance_from_path = indirect_res.radiance_from_path * srec.bsdf;
        }
        else {
            vec3 scatter_dir = srec.s_ray.direction();
            //If pdf is 0 or close, stop. Generated impossible sample. Probably shouldn't happen!
            if (srec.w_pdf <= epsilon) return empty_path_result();

            //If a volume, this is meaningless, just carry on
            double cos_theta = fmax(0.0, dot(scatter_dir, rec.get_normal()));
            //Throughput at this point (from a scattered direction, out at a ray direction)
            color throughput = srec.bsdf * cos_theta / srec.w_pdf;

            child_state.prev_bsdf_pdf = srec.w_pdf;
            child_state.overall_throughput = child_state.overall_throughput * throughput;

            indirect_res = path_trace(srec.s_ray, world, child_state);

            indirect_res.radiance_from_path = indirect_res.radiance_from_path * throughput;
        }

        return indirect_res;
    }

    /*
    path_result get_indirect_result_med(const ray& r, const world& world, const path_state& p_state, const medium_scatter_rec& srec, const medium_intersection& rec) const {
        path_result indirect_res = empty_path_result();
        path_state child_state = p_state;
        child_state.depth++;

        //If pdf is 0 or close, stop. Generated impossible sample. Probably shouldn't happen!
        if (srec.w_pdf <= epsilon) return empty_path_result();

        //No russian roulette for now
        const double p = 1.0;
        const color throughput = srec.albedo * (srec.phase_pdf / srec.w_pdf) * (1.0 / p);

        child_state.prev_bsdf_pdf = srec.w_pdf;
        child_state.overall_throughput = child_state.overall_throughput * throughput;

        indirect_res = path_trace(srec.s_ray, world, child_state);
        indirect_res.radiance_from_path = indirect_res.radiance_from_path * throughput;

        return indirect_res;
    }
    */

    path_state initial_path_state() const {
        path_state p_state;
        //Here depth starts from 0 and counts upwards
        p_state.depth = 0;
        p_state.overall_throughput = colors::white;
        p_state.prev_bsdf_pdf = 1.0;
        return p_state;
    }

    path_result color_path_result(color radiance) const {
        path_result res = empty_path_result();
        res.radiance_from_path = radiance;
        return res;
    }

    path_result empty_path_result() const {
        path_result out_result;
        out_result.radiance_from_path = color(0,0,0);
        out_result.terminated_on_light = false;
        return out_result;
    }
};

#endif //BENDERER_SIMPLE_MEDIUM_PATH_TRACER_H